function [predictLabel] = turnRealtoLabel(realPredict)
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
[row,col] = size(realPredict);
predictLabel = zeros(row,col);
realPredict = tanh(realPredict);
for j = 1 : col
    c = find(realPredict(:,j)>0);
    meanValue = mean(realPredict(c,j));
    stdValue = std(realPredict(c,j));
    for i = 1 : row
        threshold = meanValue + stdValue;
        if threshold < 0.98
          threshold = 0.98;
        end           
        if realPredict(i,j) > threshold ||realPredict(i,j)==1           
            predictLabel(i,j) = 1;
        end
    end

end

end

