function [P] = patternLearn(data,data2,beta1,beta2,beta3,beta4)

global N T lambda1 lambda2
lambda1 = 0.01; % damping factor
lambda2 = 0.1;

alpha = 0.01;  % damping factor
Iter = 0;      % the number of iteration

R = data;
R2 = data2;
[N,T] = size(R); % get the dimention of M, m: the number of users, n: the number of items
P = rand(N,N); % transition matrix P
tic; % record the time 

while  Iter < 1000
%     beta4 = beta3;
    PDP = CalPDP(P,R,R2,beta1,beta2, beta3,beta4); % partial derivative of P
    P = P - alpha*PDP; % update P
    if mod(Iter,5) == 0
        alpha = 0.95*alpha; % shrinking alpha   
%         disp([' beta1 = ', num2str(beta1), ' beta2 = ',num2str(beta2)]);
    end
    if mod(Iter,200) == 0
%         alpha = 0.95*alpha; % shrinking alpha   
        disp([' beta1 = ', num2str(beta1), ' beta2 = ',num2str(beta2)]);
    end
    Iter = Iter + 1;
end
toc;
end
