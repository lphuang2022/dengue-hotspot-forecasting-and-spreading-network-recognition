% main for learning Beta

global lambda1 lambda2 %beta1 beta2 beta3
lambda1 = 0.01; % damping factor
lambda2 = 0.1;
% beta1 = 0.76;
% beta2 = 0.2;
% beta3 = 1 - beta1 - beta2;

load('hotspot14.mat');
areaWeek = subzoneHotspotWeek14;%%%%%%%%%%%%%%%%%%% hotsporWeek (#case >=3 ) --> 1
[areaNum, weekNum] = size(areaWeek);
iterNum1 = 1;
iterNum2 = 1;
win = 5;
fromWeek = 1;
toWeek = 52;

data = areaWeek(:,fromWeek:toWeek);
data2 = subzoneHotspotPotential14(:,fromWeek:toWeek);         %%%%%%%%%%%%%%%%% data2 = hotspotPotential :#case >=2
[m,n] = size(data);
P3D = zeros(m,m,toWeek-fromWeek+1-win);
metric = zeros(1,4);     % performance
metricBest = zeros(toWeek-fromWeek+1-win,4);
betaBest = zeros(toWeek-fromWeek+1-win,4);

PredOneStep = zeros(m,toWeek-fromWeek+1-win);
PredBest = zeros(m,toWeek-fromWeek+1-win);
P3D_best = P3D;

       
 for i = 6 : toWeek-fromWeek+1-win
             
  for beta1 = 0.2 : 0.03 : 0.9
        for beta2 = 0.1: 0.03 : 0.5                      
             for beta3 = 0.1:0.03:0.3
                 for beta4 = 0.1 : 0.03 : 0.3
%                      for beta5 = 0.2 : 0.03 : 0.5
%                          iter = 1;
%                          while  iter <= iterNum1
                         [P3D(:,:,i)] = patternLearn(data(:,i:i+win-1),data2(:,i:i+win-1) ,beta1,beta2,beta3,beta4);
                         PredOneStep(:,i) = P3D(:,:,i)*(beta1*data2(:,i + win -1)+beta2*data2(:,i+win-2)+beta3*data2(:,i+win-3)+beta4*data2(:,i+win-4));
                         labelPred = turnRealtoLabel(PredOneStep(:,i));
                         [a,p,r,f1] = FMeasure(data(:,i + win ),labelPred);
                         if f1 > metricBest(i,4)
                          P3D_best(:,:,i) = P3D(:,:,i);
                          metricBest(i,:) = [a,p,r,f1];
                          PredBest(:,i) = PredOneStep(:,i);
                          betaBest(i,1) = beta1;
                          betaBest(i,2) = beta2;
                          betaBest(i,3) = beta3;
                          betaBest(i,4) = beta4;
                         end
%                          iter = iter + 1;     
%                          end % endwhile iteration
%                     end 
                 end
             end
         end % endfor beta1
   end   %endfor beta2  
end  %endfor window

figure;plot(metricBest(:,3));