function [accuracy, precision, recall,F1] = FMeasure(trueth,predict)
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
[row,col] = size(trueth);
accuracy = 0;
precision = 0;
recall = 0;
F1 = 0;
TN = 0;
TP = 0;
FP = 0;
FN = 0;
for i = 1 : row
    for j = 1: col                                % collumn starts from 1
      if trueth(i,j) == 1 && predict(i,j)==1
          TP = TP + 1;
      elseif trueth(i,j) == 1 && predict(i,j) == 0
          FN = FN + 1;
      elseif trueth(i,j) == 0 && predict(i,j) == 1
          FP = FP + 1;
      elseif trueth(i,j) == 0 && predict(i,j) == 0
          TN = TN + 1;
      else 
          break;
      end
    end
end

accuracy = (TN+TP)/(row*col);
precision = TP/(TP+FP+0.000001);
recall = TP/(TP+FN+0.000001);
F1 = 2*precision*recall/(1*precision+recall+0.000001);

end

