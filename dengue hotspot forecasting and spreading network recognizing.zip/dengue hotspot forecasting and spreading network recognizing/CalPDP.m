%%
%%%%%% calculate the partial derivative of P %%%%%%
%%%%%% input: P, R                                     %%%%%%
%%%%%% output: PDP                                  %%%%%%
%%%% batch % %%% %%%%
function PDP = CalPDP(P,R,R2,beta1,beta2,beta3,beta4)
global N T lambda1 lambda2
PDP = zeros(N,N);

for i = 1:N
    for t = 1:T-4
%         term1 = 2*P(i,:)*((beta1*R(:,t)+beta2*R(:,t+1)+beta3*R(:,t+2)).*G(:,i)-R(i,t+3)); % the first part
%         term2 = (beta1*R(:,t)+beta2*R(:,t+1)+beta3*R(:,t+2)).*G(:,i);                      % the second part
        
        term1 = 2*P(i,:)*((beta1*R2(:,t)+beta2*R2(:,t+1)+beta3*R2(:,t+2)+beta4*R2(:,t+3))-R(i,t+4)); % the first part
        term2 = (beta1*R2(:,t)+beta2*R2(:,t+1)+beta3*R2(:,t+2)+beta4*R2(:,t+3));
        term3 = 2*lambda1.*P(i,:);      % penalty
        term4 = lambda2.*sign(P(i,:));
        PDP(i,:) = PDP(i,:) + term1*term2'+ term3 + term4; % the whole partial derivative        
    end
end
end


